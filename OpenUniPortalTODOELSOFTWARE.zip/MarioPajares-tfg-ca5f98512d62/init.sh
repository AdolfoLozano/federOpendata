uwsgi --socket 0.0.0.0:8086 --protocol=http -w wsgi --process=50

