import sys

from sqlite import create_table


def main():
    create_table()
if __name__ == "__main__":
    sys.exit(main())
