//Variables para componer una consulta SPARQL:
//var preConsultaSPARQL = "http://opendata.caceres.es/sparql"; //La consulta siempre empieza igual.
var medConsultaSPARQL = "&query="; //Entre el grafo y la consulta siempre se coloca esta claúsula. 

//Variables para componer una consulta SPARQL:
 //La consulta siempre empieza igual.
//var medConsultaSPARQL = "&query="; //Entre el grafo y la consulta siempre se coloca esta claúsula. 

//Prueba
//var preConsultaSPARQL = "http://158.49.245.82/sparql/select";
 //Cáceres
var preConsultaSPARQL = "http://opendata.caceres.es/sparql";
//Gijón
//var preConsultaSPARQL = "http://datos.gijon.es/sparql";

//var preConsultaSPARQL = 'http://es.dbpedia.org/sparql';
//Zaragoza
//var preConsultaSPARQL = "http://www.zaragoza.es/datosabiertos/sparql";
//Santander
//var preConsultaSPARQL = "http://datos.santander.es/sparql/select";
//biblioteca nacional
//var preConsultaSPARQL = "http://datos.bne.es/sparql";
//upf
//var preConsultaSPARQL = "http://data.upf.edu:8890/sparql";
//FILTER (regex(?Concept,\"http://opendata.caceres.es\")) .
//var consultaSPARQLdatasets = "select distinct ?Concept where { ?URI a ?Concept } order by asc (?Concept)" 
var consultaSPARQLdatasets = 'PREFIX dbpo: <http://dbpedia.org/ontology/>  select  distinct ?Concept where { ?URI a ?Concept. }order by asc (?Concept)';

var consultaSPARQLproperties1 = 'SELECT ?p ?properties (min(?v) as ?y) WHERE{{ ?u a ';
var consultaSPARQLproperties2 = ' . ?u ?properties ?v . FILTER isLiteral(?v) .} ';

var consultaSPARQLproperties3 = 'UNION { ?u a ';
var consultaSPARQLproperties4 = ' . ?u ?p _:blankNode . _:blankNode ?properties ?v. }}order by (?p)';

//var consultaSPARQLproperties1 = "SELECT ?properties MIN(?y) where{ ?x a ";
//var consultaSPARQLproperties2 = " . ?x ?properties ?y.}GROUP BY ?properties ORDER BY ASC(?properties)";
//var consultaSPARQLproperties2 = ' . ?x ?properties ?y.  FILTER (!REGEX (?y,"node","i")).}ORDER BY ASC(?properties)';

var consultaSPARQLCompletaDatasets;
var consultaSPARQLCompletaPropiedades;
var querySPARQLCompletaDatasets;
var querySPARQLCompletaPropiedades;
var querySPARQLCompleta;

var consultaSPARQL="";
var grafoConsultaSPARQL="";

var prefixes = [];

function selectionEndPoint(e){
  switch(e){
    case "Opendata Cáceres":
      preConsultaSPARQL = "http://opendata.caceres.es/sparql";
    break;
    case "Opendata UPF":
      preConsultaSPARQL = "http://data.upf.edu:8890/sparql";
    break;
    case "DBpedia":
      preConsultaSPARQL = 'http://es.dbpedia.org/sparql';
    break;
    case "Zaragoza Datos Abiertos":
      preConsultaSPARQL = "http://www.zaragoza.es/datosabiertos/sparql";
    break;
    case "BNE":
      preConsultaSPARQL = "http://datos.bne.es/sparql";
    break;
    case "other":
      preConsultaSPARQL = prompt("Introduzca la url del EndPoint");
    break;
  }
  jQuery.ajaxSetup({async:false});

  queryDatasets();
  queryProperties();

  jQuery.ajaxSetup({async:true});
}

function getPrefixes(){
  $.post("http://158.49.245.82:8081/AsisData/GetResources",{type:"prefixes"}, function(data){
    for (rowIdx in data){
      if (data[rowIdx]!=="http"){
        prefixes[data[rowIdx]] = rowIdx;
        prefixes[rowIdx] = data[rowIdx];
      }
    }
  });
}

function queryDatasets (){
  //consultaSPARQLCompletaDatasets = preConsultaSPARQL + medConsultaSPARQL + consultaSPARQLdatasets;
  //querySPARQLCompletaDatasets = encodeURI(consultaSPARQLCompletaDatasets);
  //querySPARQLCompletaDatasets = consultaSPARQLCompletaDatasets;
  //consultaSPARQL = consultaSPARQLdatasets;
  $.post("http://158.49.245.82:8081/AsisData/GetResources",{endpoint:preConsultaSPARQL, query:consultaSPARQLdatasets, format:"json", type:"properties"}, function (data){
     updateSelectDatasets(data);
     });
  /*$.ajax({
    //data: { "default-graph-uri":grafoConsultaSPARQL, query:consultaSPARQLdatasets },
    //dataType: "json",
    data: {"default-graph-uri":grafoConsultaSPARQL, query:consultaSPARQLdatasets,format: 'json'},
    url: preConsultaSPARQL,
    cache:false,
    statusCode: {
      400: function(error) {
        $("#errorResultados").text(error.responseText);
        $("#errorResultados").css('color', 'red');
      }
    },
    success: function(data) {  
      //Actualizamos el valor del selector de datasets.
      updateSelectDatasets(data);
    }
  });*/
}

function queryProperties (){
  //prefijos += "PREFIX "+neededPrefixes[i]+": <"+prefixes[neededPrefixes[i]]+"> ";
  var aux = $("#selectorDataset option:selected").val();
  var prefijo ="";
  if( aux.substring(0,1) !== "<"){
    prefijo = "PREFIX "+ aux.split(":")[0] + ": <"+prefixes[aux.split(":")[0]]+"> ";  
  }
  
  consultaSPARQLCompletaPropiedades = prefijo + consultaSPARQLproperties1 + $("#selectorDataset option:selected").val() +consultaSPARQLproperties2 + consultaSPARQLproperties3 + $("#selectorDataset option:selected").val() + consultaSPARQLproperties4;
  //querySPARQLCompletaPropiedades = encodeURI(consultaSPARQLCompletaPropiedades);
  //consultaSPARQLCompletaPropiedades = "  PREFIX dbpo: <http://dbpedia.org/ontology/> SELECT ?p ?properties ?value WHERE {{SELECT ?properties (min(?y) as ?value) WHERE {?u a dbpo:Museum .?u ?properties ?y .FILTER isLiteral(?y) .}GROUP BY ?properties} }ORDER BY ?p";
  /* "PREFIX  om: <http://opendata.caceres.es/def/ontomunicipio#> "+
                                      "PREFIX geo: <http://www.w3.org/2003/01/geo/wgs84_pos#> "+
                                      "PREFIX schema: <http://schema.org/> " +
                                      "PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> " +
                                      "PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> "+
                                      " SELECT ?p ?properties ?y WHERE {{SELECT ?properties (min(?v) as ?y) WHERE{ ?u a om:Biblioteca . ?u ?properties ?v . FILTER isLiteral(?v) .}} UNION { SELECT ?p ?properties (min(?v) as ?y) WHERE{ ?u a om:Biblioteca . ?u ?p _:blankNode . _:blankNode ?properties ?v. }}}order by (?p)";
  */
  //alert(consultaSPARQLCompletaPropiedades);
  
  querySPARQLproperties = "select  distinct ?Concept where { ?URI a ?Concept. }order by asc (?Concept)";
  $.post("http://158.49.245.82:8081/AsisData/GetResources",{endpoint:preConsultaSPARQL, query:consultaSPARQLCompletaPropiedades, format:"json", type:"properties"}, function (data){
     updateTableProperties(data);
     });
/*  $.ajax({
    data: { "default-graph-uri":grafoConsultaSPARQL, query:consultaSPARQLCompletaPropiedades },
    dataType: "json",
    url: preConsultaSPARQL,
    cache:false,
    statusCode: {
      400: function(error) {
        $("#errorResultados").text(error.responseText);
        $("#errorResultados").css('color', 'red');
      }
    },
    success: function(data) {  
      updateTableProperties(data);
      //updateTableProperties(data);
    }
  });*/
}

function queryToDownload(format,query){
  var queryToFormat = preConsultaSPARQL+"?default-graph-uri="+encodeURIComponent(grafoConsultaSPARQL)+"&query="+encodeURIComponent(query);
        
  switch(format){
    case '0':   open(queryToFormat+"&format=xml");
      break;
    case '1':   open(queryToFormat+"&format=json");
      break;
    case '2':   open(queryToFormat+"&format=csv");
      break;
    case '3':   open(queryToFormat+"&format=rdf");
      break;
    case '4':   open(queryToFormat+"&format=text%2Fplain");
      break;
    default:
      alert("ERROR");
  }
}

function prepararConculta(){

//formulario tableProperties
  var fp = document.forms["tableProperties"];
  //checkbox isSelected or isOptional
  var elems = fp['isPropertySelected'];
  var prop = fp['property'];
  var elemo = fp['isPropertyOptional'];
  //var filters = fp['filter'];
  //var filtersData  = fp['filterText'];
  var tableReg = document.getElementById('tablaPropiedades');
  var rows = tableReg.rows.length -1;
  var cbc;
  var dat;

  var propertiesSelected = false;
  //for (i in tableReg.rows && !propertiesSelected) {
  for (var i = 0; i < rows && !propertiesSelected; i++) {
      
    cbc = elems[i];
    if (cbc.checked) {
      propertiesSelected = true;
    }
  }


   if(!propertiesSelected){
    //mostrar mensaje: Por favor, seleccione alguna propiedad para realizar la consulta
    return -1;
  }else{

    //parametros de configuración adicionales: order by ... asc/desc ... limit ... offset ...
    var optionalConfigureParams;
    //[isSelected?,isOptional?]
    var property;    
    var cellsOfRow="";
    var filterOfRow="";
    var propiedadesSeleccionadas =[];
    var propertyAndOptional;
    var countPropiedades = 0;
    var filter;
    var numberFilters = -1;
    // Recorremos todas las filas con contenido de la tabla
    for (i = 0; i < rows; i++)
    {
      cellsOfRow = tableReg.rows[i+1].getElementsByTagName('td');
      propertyAndOptional = [];
      
        if (elems[i].checked) { 
          propertyAndOptional[0]=cellsOfRow[1].innerHTML.replace("<p>","").replace("</p>","");
         
          if(elemo[i].checked){ 
            propertyAndOptional[1]=true;
          }else{
            propertyAndOptional[1]=false;
          }
          

          if ($("#filter"+(i).toString()).length > 0 ) {
            filter = $("#filter"+(i).toString()+" option:selected").val();
            propertyAndOptional[2]=document.getElementById("filter"+(i).toString()).name;
            propertyAndOptional[3]=filter;
            if (filter !== 0) {
               propertyAndOptional[4]=$("#filterText"+(i).toString()).val();
               propertyAndOptional[5]=$("#filterText2-"+(i).toString()).val();
            }
          }else{
            propertyAndOptional[2]=0;
            propertyAndOptional[3]=0;
          }

          propiedadesSeleccionadas[countPropiedades]=propertyAndOptional; 
          countPropiedades++;
      }
   
    }
    return construirConsulta(propiedadesSeleccionadas);
   }
  
}
function addPrefix(p){
  var aux = p.replace(" ","");//propiedadesSeleccionadas[i][0].split(":")[0];
  var neededPrefixes = queryPrefixes;
  var isThisPrefix = false;
  for (var j = 0; j< neededPrefixes.length;j++){
    if(aux === neededPrefixes[j]){
      isThisPrefix = true;
    }
  }
  if(isThisPrefix ===false){
    neededPrefixes[neededPrefixes.length] = aux;
  }else{
    isThisPrefix = false;
  }

  return neededPrefixes;
}

var queryPrefixes = [];
var nestedQuery = []; //almacena las clases de las consultas anidadas, para que llevar un control y que estas no esten repetidas
var selected=""; 
function addPropSelected(dat_property){
  var pos;
  var property = dat_property[0];
  var isObligatory = dat_property[1];
  var filter = dat_property[2];
  var prop ="";
  var query = "";
  //comprobación consulta anidada
  var p = property.split(" - ");
  if(p.length === 2){
    if (nestedQuery[p[0]] === undefined){
      nestedQuery[p[0]] = p[0];

    }//consulta por la clase ya realizada, ahora preguntamos por la propiedad de esta
      if(p[1].substring(0,5) === "http:"){//prefijo no reconocido
        pos = p[1].search('#')+1;
        if(pos===0){
          pos=p[1].lastIndexOf('/')+1;
        }
        pos0 = p[0].search('#')+1;
        if(pos0===0){
          pos0=p[0].lastIndexOf('/')+1;
        }
        if(pos0===0){
          pos0=p[0].lastIndexOf(':')+1;
        }
        aux = p[0].substring(pos0).replace("-","_");
        if(isObligatory){
          query += "?"+aux+" <"+p[1]+"> ?"+aux+"_"+p[1].substring(pos).replace("-","_")+".";
        }else{
          query += "OPTIONAL{ ?"+aux+" <"+p[1]+"> ?"+aux+"_"+p[1].substring(pos).replace("-","_")+".}.";
        }
        
      }else{//con prefijo reconocido
        pos = p[1].search(':')+1;
        pos0 = p[0].search('#')+1;
        if(pos0===0){
          pos0=p[0].lastIndexOf('/')+1;
        }
        if(pos0===0){
          pos0=p[0].lastIndexOf(':')+1;
        }
        aux = p[0].substring(pos0).replace("-","_");
        addPrefix(p[1].split(":")[0]);
        if(isObligatory){
          query += "?"+aux+" "+p[1]+" ?"+aux+"_"+p[1].substring(pos).replace("-","_")+".";
        }else{
          query += "OPTIONAL{ ?"+aux+" "+p[1]+" ?"+aux+"_"+p[1].substring(pos).replace("-","_")+".}.";
        }

      }
    prop = aux+"_"+p[1].substring(pos).replace("-","_"); 
  }else{
  //consulta simple
    if(property.substring(0,5) === "http:"){//prefijo no reconocido
      pos = property.search('#')+1;
      if(pos===0){
        pos=property.lastIndexOf('/')+1;
      }
      if(isObligatory){
        query += "?uri <"+property+"> ?"+property.substring(pos).replace("-","_")+".";
      }else{
        query += "OPTIONAL{ ?uri <"+property+"> ?"+property.substring(pos).replace("-","_")+".}.";
      }
    }else{//con prefijo reconocido
      pos = property.search(':')+1;
      addPrefix(property.split(":")[0]);
      if(isObligatory){
        query += "?uri "+property+" ?"+property.substring(pos).replace("-","_")+".";
      }else{
        query += "OPTIONAL{ ?uri "+property+" ?"+property.substring(pos).replace("-","_")+".}.";
      }
    }
    prop = property.substring(pos).replace("-","_");
  } 
  selected += " ?"+prop;

  //añadir filtros
  var filters ="";
  var typeC;
    if(dat_property[3]!=0){

      

      switch(dat_property[2])
      {
        case 'xsd:date':typeC = dat_property[3];
                       if (typeC === "Rango"){
                         filters += 'FILTER ( xsd:date(?'+prop+') > xsd:date(\"'+dat_property[4]+'\")) .';
                         filters += 'FILTER ( xsd:date(?'+prop+') < xsd:date(\"'+dat_property[5]+'\")) .';
                       }else{
                         filters += 'FILTER ( xsd:date(?'+prop+') '+ typeC +' xsd:date(\"'+dat_property[4]+'\")) .';
                       } 
                       break;
        case 'number': typeC = dat_property[3];
                       if (typeC === "Rango"){
                        filters += 'FILTER ( ?'+prop + ' > \"'+dat_property[4]+'\"^^xsd:decimal) .';
                        filters += 'FILTER ( ?'+prop + ' < \"'+dat_property[5]+'\"^^xsd:decimal) .';
                       }else{
                        filters += 'FILTER ( ?'+prop + ' ' + typeC +' \"'+dat_property[4]+'\"^^xsd:decimal) .';
                       }
                       break;
        case 'literal':   if(dat_property[3]=="toInclude"){
                          filters += 'FILTER REGEX(?'+prop+',\"'+dat_property[4]+'\","i") .';
                        }else{
                          if (dat_property[3]=="=") {
                            filters += 'FILTER (str(?'+prop+') = "'+dat_property[4]+'")';
                          }
                        }
                        break;
      

      }
    }
  return query+" "+filters;
}


function construirConsulta(propiedadesSeleccionadas){

  queryPrefixes = [];
  nestedQuery = [];
  var consulta = 'SELECT ';
  var propiedades = [];
  var prefixURL = [];
  var coor=0;
  var neededPrefixes = []; var isThisPrefix = false; lengthNeededPrefixes = 0;
  consulta += /*radioSelected +*/ " ?uri ";
  selected="";
  var pos;

    //consulta += ' ?'+propiedades[i].replace("-","_");

    //if(propiedades[i] === "lat"){ coor++}
    //else {if(propiedades[i] ==="long") {coor++;}}
  //}


  var filters = "";
  var aux = $("#selectorDataset option:selected").val();
  if(aux.search("http://") === -1){
    queryPrefixes[0]= aux.split(":")[0];
  }//lengthNeededPrefixes++;
  var auxQuery = "";
  for(i in propiedadesSeleccionadas){
    auxQuery+=addPropSelected(propiedadesSeleccionadas[i]);
  }
  
  consulta += selected;
  if ((selected.search(" ?lat"))!==-1) {
    coor++;
  }
  if((selected.search(" ?long"))!==-1){
    coor++;
  }
  consulta += ' WHERE {';
  consulta += '?uri a '+ $("#selectorDataset option:selected").val() +'.\n';
  for (var x in nestedQuery){
    if(nestedQuery[x].substring(0,5) === "http:"){//prefijo no reconocido
      pos = nestedQuery[x].search('#')+1;
      if(pos===0){
        pos=nestedQuery[x].lastIndexOf('/')+1;
      }
      consulta += "?uri <"+nestedQuery[x]+"> ?"+nestedQuery[x].substring(pos).replace("-","_")+".";
    }else{//prefico de la clase reconocid
      pos = nestedQuery[x].search(':')+1;
      addPrefix(nestedQuery[x].split(":")[0]);
      consulta += "?uri "+nestedQuery[x]+" ?"+nestedQuery[x].substring(pos).replace("-","_")+".";
    }
  }
  consulta+= auxQuery;
  
 

  //////////////////////////////////
  //Rango de distancia desde un punto
  //FILTER (bif:st_distance(bif:st_point(,),bif:st_point(,))<1); distancia en km
  var el = document.getElementById("geoCompare");
  var geoCmp ="";
  if(el.checked && coor===2){
    var isXsd = false;
    for ( var y in queryPrefixes){
      if(queryPrefixes[y] === "xsd"){
        isXsd = true;
      }
    }
    if(!isXsd){
      queryPrefixes[queryPrefixes.length] = "xsd";
//      lengthNeededPrefixes++;
    }
    geoCmp = "FILTER (<bif:st_distance>(<bif:st_point>(?long,?lat),<bif:st_point>(\""+document.getElementById("longToCompare").value+"\"^^xsd:decimal,\""+document.getElementById("latToCompare").value+"\"^^xsd:decimal))<"+document.getElementById("distanceToCompare").value/1000+") .";
  }else{
    geoCmp="";
  }

  ////////////////////////////////////

  consulta+=geoCmp+'}';

  /////////////////////// prametros de configuracion opcionales //////////////////////////////////////

  //ORDER BY
  var orderBySelection = $("#selectOrderBy option:selected").val();
  if ( orderBySelection != "none") {
    consulta += "ORDER BY ";// + orderBySelection;
    //ASC/DESC 
    var orderModeSelection = $("#selectOrderMode option:selected").val();
    var modeSelection = $("#OrderMode option:selected").val();
    
    //ORDER BY ASC/DESC ELEMENT
    consulta += modeSelection + "(?" + orderBySelection + ") ";

  }
  //LIMIT
  var limitSelection = $("#limit").val();
  if(limitSelection > 0){
    consulta += " LIMIT " + limitSelection;
  }else{
    consulta += " LIMIT 100";    
  }

  //OFFSET
  var offsetSelection = $("#offset").val();
  if (offsetSelection > 0) {
    consulta += " OFFSET " + offsetSelection;
  }

  var prefijos = "";

  for (var i=0; i< queryPrefixes.length;i++){
    prefijos += "PREFIX "+queryPrefixes[i]+": <"+prefixes[queryPrefixes[i]]+"> ";
  }

  prefijos += consulta;
  return prefijos;
}


