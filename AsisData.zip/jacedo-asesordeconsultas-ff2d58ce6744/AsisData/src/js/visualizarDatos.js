( function( $ ) {
$( document ).ready(function() {

$('#menuEndPoints > ul > li > a').click(function() {
  $('#menuEndPoints li').removeClass('active');
  $(this).closest('li').addClass('active'); 
});
});
} )( jQuery );


var prefixes;

function filterVisibility(num){

  var elemt = document.getElementById("filter"+num.toString());
  
  if (elemt.value === "Rango") {
    document.getElementById("filterText2-"+num.toString()).style.display = "block";
    if (document.getElementById("lanzador2-"+num.toString()) !== null) {
        document.getElementById("lanzador2-"+num.toString()).style.display = "block";
    }
  }else{
    document.getElementById("filterText2-"+num.toString()).style.display = "none";
    if (document.getElementById("lanzador2-"+num.toString()) !== null) {
        document.getElementById("lanzador2-"+num.toString()).style.display = "none";
    }
  }
  var elem = elemt.selectedIndex;
  elem = elemt.value;
  elem = elemt.id;
}
/*function getPrefixes(){

$.get("http://opendata.caceres.es/sparql?nsdecl", function(data){
  //prefijos = data.match(RegExPattern);
  var prefijos = data.split('<tr><td>');
  var temp;
  prefixes = [];
  for (var i = 1 ; i < prefijos.length ; i++){
    temp = prefijos[i].split('</td><td>');
    prefixes[i-1] = [temp[0],temp[1].substring(0,temp[1].indexOf('</td></tr>\n'))];
  }

});
}
*/
function updateSelectDatasets(data){
  var headers = data.head.vars;
  var bindings = data.results.bindings;
  var value;

  $('#selectorDataset').html('');
  var Datasets = $("#selectorDataset");
  //Borramos los resultados anteriores
 // Datasets.find('option').remove();
  for(var i = Datasets.length-1; i>0; i--){
    Datasets.remove(i);
  }


  var dat;
  //var datDataset;
  var uriDatasets = []; 

 
  var pos=null;
  for(rowIdx in bindings){
      dat="";    
      value = bindings[rowIdx]["Concept"];
      if (value["type"] !== "bnode") {
        dat = value["value"];
        pos = dat.search("#")+1;
        if (pos === 0){
          pos = dat.lastIndexOf("/")+1;
        }
      }

      var classToAdd ="";

      var datDataset =[];
      datDataset[0] = dat.substring(0,pos);
      datDataset[1] = dat.substring(pos);

      if(prefixes[datDataset[0]] !== undefined){
        datDataset[0] = prefixes[datDataset[0]];
        classToAdd = datDataset[0]+":"+datDataset[1];
      }else{
        classToAdd = "<"+dat+">";
      }
      

      Datasets.append(new Option(classToAdd));    

  }


  Datasets[0].selected = "selected";

}



/////////////////TABLA DE PROPIEDADES///////////////////////
function updateTableProperties(data){

  var headers = data.head.vars;
  var bindings = data.results.bindings;

  var value,type,property,propertyClass,pos;

  
  var tabla =    '<thead class="fixed-header">'+
                    '<tr >'+
                      //checkbox isSelected?
                      '<th class="column-header" data-field="isSelected" title="isSelected" style="min-width: 30px; max-width:30px;"><input id="isSelected" type="checkbox" onClick="selectedUnselected(this,\'isPropertySelected\');"/></th>'+
                      //Propiedades
                      '<th class="column-header" data-field="Propiedades" title="Propiedades" style="min-width: 250px; max-width: 250px;"><p>Propiedades</p></th>'+
                      //checkbox isoptional?
                      '<th class="column-header" data-field="isOptional" title="isOptional" style="min-width: 120px; max-width:120px;"><p>Obligatorio</p><input id="isOptional" type="checkbox" onClick="selectedUnselected(this,\'isPropertyOptional\');"/></th>'+
                      //Filtros
                      '<th class="column-header" data-field="Filters" title="Filters" style="min-width: 90px; max-width:90px;"><p>Filtro</p></th>'+
                      //dato a comparar
                      '<th class="column-header" data-field="dateToCompare" title="dateToCompare" style="min-width: 90px; max-width: 90px;"></th>'+
                      '<th class="column-header" data-field="dateToCompare2" title="dateToCompare2" style="min-width: 90px; max-width: 90px;"></th>'+
                    '</tr >'+
                  '</thead >'+
                  '<tbody class="scroll-content" style="max-height:250px;">';
                tr = '';


  //var property, prop;
  //var type;
  var dates = [];
  var count = 0;

  for (rowIdx in bindings){

    value = bindings[rowIdx];
    //property = value[headers[1]]["value"];

    
    if (typeof(value[headers[0]])!=='undefined'){ //&& prop != "http://www.w3.org/1999/02/22-rdf-syntax-ns#type") {
      //prop = value[headers[0]]["value"];
      propertyClass = value[headers[0]]["value"];
      
      pos = propertyClass.search("#")+1;
      if (pos === 0){
        pos = propertyClass.lastIndexOf("/")+1;
      }

      if(prefixes[propertyClass.substring(0,pos)]!==undefined){
        propertyClass = prefixes[propertyClass.substring(0,pos)]+":"+propertyClass.substring(pos);
      }
    }else{
      propertyClass = null;
    }

    if(value[headers[1]] !== undefined){
      property = value[headers[1]]["value"];
      if (property != "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"){
      
        pos = property.search("#")+1;
        if (pos === 0){
          pos = property.lastIndexOf("/")+1;
        }

        if(prefixes[property.substring(0,pos)]!==undefined){
          property = prefixes[property.substring(0,pos)]+":"+property.substring(pos);
        }
        tr += '<tr>'+
                '<td data-field="isSelected" style="min-width: 30px; max-width: 30px;"><input type="checkbox" name="isPropertySelected"  onClick="updateSelector(this,'+count.toString()+');"/></td>';
        if (propertyClass !== null) {
          tr += '<td data-field="Propiedades" style="min-width: 250px; max-width: 250px;"><p>'+propertyClass+' - '+property+'</p></td>'; 
        }else{
          tr += '<td data-field="Propiedades" style="min-width: 250px; max-width: 250px;"><p>'+property+'</p></td>';
        }

        type = value[headers[2]]['type'];
        if(type=='typed-literal'){
          type = value[headers[2]]['datatype'];//.replace('http://www.w3.org/2001/XMLSchema#','xsd:');

          pos = type.search("#")+1;
          if (pos === 0){
            pos = type.lastIndexOf("/")+1;
          }

          if(prefixes[type.substring(0,pos)]!==undefined){
            type = type.substring(pos);
          }
        }
        
        tr += '<td data-field="isOptional" style="min-width: 120px; max-width: 120px;"><input type="checkbox" name="isPropertyOptional" /></td>';
      
        switch(type){
          case 'literal': tr += '<td data-field="Filters" style="min-width: 90px; max-width: 90px;">'+
                                '<select id="filter'+count.toString()+'\" name="literal" style="min-width: 90px; max-width: 90px;">'+
                                  '<option value="0">Ninguno</option>'+
                                  '<option value=\"toInclude\">que contenga</option>'+
                                  '<option value="=">=</option>'+
                                '</select>'+
                              '</td >'+
                              '<td data-field="dateToCompare" style="min-width: 90px; max-width:90px;">'+
                                '<input type="text" id="filterText'+count.toString()+'\" style="min-width: 80px; max-width: 80px;"/>'+
                              '</td >'+
                              '<td data-field="dateToCompare2" style="min-width:90px; max-width: 90px;">'+
                                '<input type="text" id="filterText2-'+count.toString()+'\" style="min-width: 80px; max-width: 80px;display:none;"/>'+
                              '</td >';
                        break;
          case 'double':
          case 'float':
          case 'int':
          case 'decimal':tr += '<td data-field="Filters" style="min-width: 90px; max-width: 90px;">'+
                                '<select onchange="filterVisibility('+count.toString()+')" id="filter'+count.toString()+'\" name="number" style="width: 90px; max-width: 90px;">'+
                                  '<option value="0">Ninguno</option>'+
                                  '<option value=\"=\">\=</option>'+
                                  '<option value=\"<\">\<</option>'+
                                  '<option value=\">\">\></option>'+
                                  '<option value=\"<=\">\<\=</option>'+
                                  '<option value=\">=\">\>\=</option>'+
                                  '<option value=\"Rango\">Rango(x,y)</option>'+
                                '</select>'+
                              '</td >'+
                              '<td data-field="dateToCompare" style="min-width: 90px; max-width: 90px;" >'+
                                '<input type="text" id="filterText'+count.toString()+'\" style="width: 80px; max-width: 80px;"/>'+
                              '</td >'+
                              '<td data-field="dateToCompare2" style="min-width: 90px; max-width: 90px;">'+
                                '<input type="text" id="filterText2-'+count.toString()+'\" style="min-width: 80px; max-width: 80px;display:none;"/>'+
                              '</td >';
                        break; 
          case 'date':tr += '<td data-field="Filters" style="min-width: 90px; max-width: 90px;">'+
                                '<select onchange="filterVisibility('+count.toString()+')" id="filter'+count.toString()+'\" name=\"xsd:date\" style="width: 90px; max-width: 90px;">'+
                                  '<option value=\"0\">Ninguno</option>'+
                                  '<option value=\"=\">\=</option>'+
                                  '<option value=\"<\">\<</option>'+
                                  '<option value=\">\">\></option>'+
                                  '<option value=\"<=\">\<\=</option>'+
                                  '<option value=\">=\">\>\=</option>'+
                                  '<option value=\"Rango\">Rango(x,y)</option>'+
                                '</select>'+
                              '</td >'+
                              '<td data-field="dateToCompare" style="min-width: 90px; max-width: 90px;">'+
                                '<input type="date" name="date" id="filterText'+count.toString()+'\" style="min-width: 80px; max-width: 80px;"/><img style="margin-left:5px;" id=\"lanzador'+count.toString()+'\" src="jscalendar-1.0/img.gif" />'+
                                //'<input type="date" name="date" id=\"filterText2'+count.toString()+'\" style="min-width: 80px; max-width: 80px;"/><img style="margin-left:10px;" id=\"lanzador2'+count.toString()+'\" src="jscalendar-1.0/img.gif" />'+
                              '</td>'+
                              '<td data-field="dateToCompare2" style="min-width: 90px; max-width: 90px;">'+
                                '<input type="date" name="date" id="filterText2-'+count.toString()+'\" style="min-width: 80px; max-width: 80px; display:none;"/><img style="margin-left:5px;display:none;" id=\"lanzador2-'+count.toString()+'\" src="jscalendar-1.0/img.gif" />'+
                                //'<input type="date" name="date" id=\"filterText2-'+count.toString()+'\" style="min-width: 80px; max-width: 80px;"/><img style="margin-left:10px;" id=\"lanzador2'+count.toString()+'\" src="jscalendar-1.0/img.gif" />'+
                              '</td>';
                        dates.push(count.toString());
                        break; 

          default:        //uri, 
                        tr += '<td data-field="Filters" style="min-width: 90px; max-width: 90px;">'+
                                /*'<select id=\"filter'+count.toString()+'\" style="width: 140px; max-width: 140px;">'+
                                  '<option value=\"0\">Ninguno</option>'+
                                '</select>*/'</td >'+
                              '<td data-field="dateToCompare" style="min-width: 90px; max-width: 90px;">'+
                                '<input type="text" id="filterText'+count.toString()+'\" style="width: 80px; max-width: 80px; display:none;"/>'+
                              '</td>'+
                              '<td data-field="dateToCompare2" style="min-width: 90px; max-width: 90px;">'+
                                '<input type="text" id="filterText2-'+count.toString()+'\" style="width: 80px; max-width: 80px; display:none;"/>'+
                              '</td>';
                        break;               
        }
          
        tr += '</tr >';
        count ++;
      }
    }
  } 
    tabla += tr;
    tabla += '</tbody ></table >';


    $('#tablaPropiedades').html( tabla );
  
    for (i in dates){
      Calendar.setup({
        inputField     :    "filterText"+dates[i],     // id del campo de texto
        ifFormat     :     "%Y-%m-%d",     // formato de la fecha que se escriba en el campo de texto     
        button     :    "lanzador"+dates[i]     // el id del botón que lanzará el calendario
      });
      Calendar.setup({
        inputField     :    "filterText2-"+dates[i],     // id del campo de texto
        ifFormat     :     "%Y-%m-%d",     // formato de la fecha que se escriba en el campo de texto     
        button     :    "lanzador2-"+dates[i]     // el id del botón que lanzará el calendario
      });
    } 


    $('#selectOrderBy').find('option').remove();
    $('#selectOrderBy').append($('<option/>', { 
        value: "none",
        text : "" 
    }));
    $('#selectOrderMode').find('option').remove().append('<option value="none"></option>');
    $('#selectOrderMode').append($('<option/>', { 
        value: "none",
        text : "" 
    }));
  
}

//marcar o desmarcar todas las opciones correspondientes a un checkbox
function selectedUnselected(cbc,element){

  //formulario tableProperties
  var fp = document.forms['tableProperties'];
  var elem = fp[element];
  var tableReg = document.getElementById("tablaPropiedades");

  //checkbox isSelected or isOptional
  //var cbc = document.getElementById(element);
  //variable donde obtendremos los checkbox a modificar
  var el;
  //numero de filas de la tabla sin contar la cabecera
  var max = tableReg.rows.length -1;

  for (i=0; i < max ; i++)
  { 
    
      el = elem[i];
      if(cbc.checked){
        if(el.checked === false)
        {
          //el.checked = true;
          el.click();
          if(element === "isSelected") updateSelector(el,i);
        }
      }else{
        if(el.checked)
        {
          //el.checked = false;
          el.click();
          if(element === "isSelected") updateSelector(el,i);
        }
      }
    //}
  }
}

function updateSelector(element,num){

  var fo = document.forms["aditionalOptions"];
  var orderBy = fo["selectOrderBy"];
  var orderMode = fo["selectOrderMode"];
  var isChecked = $(element).is(":checked");
  var pos;
  //$(element).attr('value', this.checked ? 1 : 0);

  var maxAllowed = 50;
  var count = $("input[name='isPropertySelected']:checked").length;
  if (count>maxAllowed) {
    $(element).prop("checked","");
   // alert('Puede seleccionar como máximo '+maxAllowed+" propiedades!!");
  }else{
    
    var tableReg = document.getElementById('tablaPropiedades');
    //obtenemos propiedad de la tabla
    //num+1 porque hay que obviar la cabecera de la tabla
    var dat = tableReg.rows[num+1].getElementsByTagName('td')[1].innerHTML;
    var dt = null;
    //obtener propiedad de la url
    dat = dat.replace('</p>','').replace(' - ','_').split('_');
    if(dat.length === 2){
      pos = dat[0].search(':')+1; 
      if (pos === 0) {
        pos = dat[0].lastIndexOf('/')+1;
      }
      dt = dat[0].substring(pos); 
      pos = dat[1].search(':')+1; 
      if (pos === 0) {
        pos = dat[1].lastIndexOf('/')+1;
      }
      dt += '_' + dat[1].substring(pos);
    }else{
      pos = dat[0].search(':')+1; 
      if (pos === 0) {
        pos = dat[0].lastIndexOf('/')+1;
      }
      dt = dat[0].substring(pos);
    }
        
    var optionToAdd = dt;

    var optionOB = document.createElement("option");
    optionOB.text = optionToAdd;
    optionOB.value = optionToAdd;
    var optionOM = document.createElement("option");
    optionOM.text = optionToAdd;
    optionOM.value = optionToAdd;
    //añadir opcion al select
    if (!isChecked) {
      $("#selectOrderBy option[value='"+optionToAdd+"']").remove();
      //$("#selectOrderMode option[value='"+optionToAdd+"']").remove();
    }else{
      //orderBy.append("<option value='"+optionToAdd+"'>"+optionToAdd+"</option>");
      //orderMode.append("<option value='"+optionToAdd+"'>"+optionToAdd+"</option>");
      orderBy.appendChild(optionOB);
      //orderMode.appendChild(optionOM);
    }
  }
}

////////////////TABLA DE RESULTADOS///////////////////
//Método que procesa el resultado de la petición para rellenar una tabla html con los datos.
function rellenarTabla(data){
    
  // Obtener la tabla de resultados.
  var table = $("#tableResults");        

  // Comenzar el índice de las filas de la tabla a cero.
  idRowResultados = 0;      

  // Obtener las variables de la consulta SPARQL de la cabecera.
  //var headerVars = data.head.vars; 
  var headerVars = data[0];
  // Utilizando las variables hacer la cabecera de la tabla.
  //var trHeaders = getTableHeaders(headerVars);
  //table.append(trHeaders);  
  var trHeaders = getTableHeaders(headerVars);
  table.append(trHeaders);
  // Obtener los resultados de "data".                                          
  //var bindings = data.results.bindings;
  var bindings = [];
  for (var i = 1; i <data.length; i++) {
    bindings[i-1]=data[i];
  }
  // Para cada resultado, hacer una fila de la tabla y añadirla a la tabla.
  //for(rowIdx in bindings){
    //table.append(getTableRow(headerVars, bindings[rowIdx]));
  //} 
  for (rowIdx in bindings) {
    table.append(getTableRow(headerVars,bindings[rowIdx]));
  }
}

//Función para crear la cabecera de la tabla.
function getTableHeaders(headerVars) {
  var trHeaders = $("<thead><tr></tr></thead>"); //crea un tr, es decir un rable row.
  for(var i in headerVars) {
    trHeaders.append( $("<th align=center>" + headerVars[i] + "</th>") ); //Th significa table header, es decir un título de columna.
  }
  return trHeaders;
}


//Se crean las filas de la tabla
function getTableRow(headerVars, rowData) {
  var tr = $("<tr class = \"tablaResultados\" id = \""+idRowResultados+"\"></tr>"); //crea un tr, es decir un rable row.
  idRowResultados = idRowResultados + 1;
  for(var i in headerVars) {
    tr.append(getTableCell(headerVars[i], rowData));
  }
  return tr;
}

//Rellenamos cada celda con el valor correspondiente.
function getTableCell(fieldName, rowData) {
  var td = $("<td class \"celdaResultados\"></td>"); //Una casilla en una tabla = td.
  if(rowData.hasOwnProperty(fieldName)){//Si existe el campo se pone el valor, si no ponemos un guión(-).
    var fieldData = rowData[fieldName];
    td.html(fieldData["value"]);
  }
  else{
    td.html("-");
  }

  return td;
}