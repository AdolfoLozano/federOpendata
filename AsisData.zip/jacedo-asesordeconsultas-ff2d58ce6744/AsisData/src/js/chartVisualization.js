

//representar datos en una tabla
function drawTableRecline(dat){
   
      
      /*
      Converts a Comma Separated Values string into an array of arrays. Each line in the CSV becomes an array.
Empty fields are converted to nulls and non-quoted numbers are converted to integers or floats.
    csvString: the csv string to parse
    dialect: [optional] hash with keys as per the CSV dialect description format. It also supports the following additional keys:
        skipInitialRows: [optional] integer number of rows to skip (default 0)
    For backwards compatability with earlier versions of the library the dialect also supports the following:
        trim: mapped to skipInitialSpace in CSV dialect description format

    https://github.com/okfn/csv.js
    */
      var data = dat; 


/*
      var datasetMap = new recline.Model.Dataset({
        records: data});

      var $elem = $('#myMap');
      var map = new recline.View.Map({
        model: datasetMap
      });

      map.infobox = function(record) {
        var html = '<h3>' + record.get('label') + ' &ndash; '+ '</h3>';
        return html;
      }
      $elem.append(map.el);
      map.render();*/
      
      //window.multiView = null;
      //window.explorerDiv = $('.data-explorer-here');
      var $el = $('#mygrid');
      // create the demo dataset
      var dataset = new recline.Model.Dataset({
        records: data});
      
      // make MultivView
     // var reload = false;
      //if (window.multiView) {
       // window.multiView.remove();
        //window.multiView = null;
        //reload = true;
      //}

      //var $el = $('<div />');
      //$el.appendTo(window.explorerDiv);

//   var $el = $('#mygrid');

  //$el.appendTo(window.explorerDiv);
     
  
      //window.multiview=null;

      var views = [
        {
          id: 'grid', // used for routing
          label: 'Grid', // used for view switcher
          view: new recline.View.Grid({
            model: dataset
          })
        },
        {
          id: 'graph',
          label: 'Graph',
          view: new recline.View.Graph({
            model: dataset
          })
        },
       /* {
          id: 'map',
          label: 'Map',
          view: new recline.View.Map({
            model: dataset
          })

        }*/
       
      ];

      /*sidebarViews: (optional) the sidebar views (Filters, Fields) 
      for MultiView to show. This is an array of view hashes. 
      If not provided initialize with (recline.View.)FilterEditor and 
      Fields views (with obvious id and labels!).*/
/*
      var sidebarViews = [
        {
          id: 'filterEditor', // used for routing
          label: 'Filters', // used for view switcher
          view: new recline.View.FilterEditor({
            model: dataset
          })
        },
        {
          id: 'fieldsView',
          label: 'Fields',
          view: new recline.View.Fields({
            model: dataset
          })
        }
        
      ];

*/

      var multiview = new recline.View.MultiView({
        model: dataset,
        el: $el,
        views: views
      });


      //window.multiview = multiview;



      /*var grid = new recline.View.SlickGrid({
        model: dataset,
        el: $el
      });
      grid.visible = true;
      grid.render();*/



}


/*
<script src="app.js" type="text/javascript"></script>
jQuery(function($) {
window.multiView = null;
window.explorerDiv = $('.data-explorer-here');
// create the demo dataset
var dataset = createDemoDataset();
// now create the multiview
// this is rather more elaborate than the minimum as we configure the
// MultiView in various ways (see function below)
window.multiview = createMultiView(dataset);
// last, we'll demonstrate binding to changes in the dataset
// this will print out a summary of each change onto the page in the
// changelog section
dataset.records.bind('all', function(name, obj) {
var $info = $('<div />');
$info.html(name + ': ' + JSON.stringify(obj.toJSON()));
$('.changelog').append($info);
$('.changelog').show();
});
});
// create standard demo dataset
function createDemoDataset() {
var dataset = new recline.Model.Dataset({
records: [
{id: 0, date: '2011-01-01', x: 1, y: 2, z: 3, country: 'DE', title: 'first', lat:52.56, lon:13.40},
{id: 1, date: '2011-02-02', x: 2, y: 4, z: 24, country: 'UK', title: 'second', lat:54.97, lon:-1.60},
{id: 2, date: '2011-03-03', x: 3, y: 6, z: 9, country: 'US', title: 'third', lat:40.00, lon:-75.5},
{id: 3, date: '2011-04-04', x: 4, y: 8, z: 6, country: 'UK', title: 'fourth', lat:57.27, lon:-6.20},
{id: 4, date: '2011-05-04', x: 5, y: 10, z: 15, country: 'UK', title: 'fifth', lat:51.58, lon:0},
{id: 5, date: '2011-06-02', x: 6, y: 12, z: 18, country: 'DE', title: 'sixth', lat:51.04, lon:7.9}
],
// let's be really explicit about fields
// Plus take opportunity to set date to be a date field and set some labels
fields: [
{id: 'id'},
{id: 'date', type: 'date'},
{id: 'x', type: 'number'},
{id: 'y', type: 'number'},
{id: 'z', type: 'number'},
{id: 'country', 'label': 'Country'},
{id: 'title', 'label': 'Title'},
{id: 'lat'},
{id: 'lon'}
]
});
return dataset;
}
// make MultivView
//
// creation / initialization in a function so we can call it again and again
var createMultiView = function(dataset, state) {
// remove existing multiview if present
var reload = false;
if (window.multiView) {
window.multiView.remove();
window.multiView = null;
reload = true;
}
var $el = $('<div />');
$el.appendTo(window.explorerDiv);
// customize the subviews for the MultiView
var views = [
{
id: 'grid',
label: 'Grid',
view: new recline.View.SlickGrid({
model: dataset,
state: {
gridOptions: {
editable: true,
// Enable support for row add
enabledAddRow: true,
// Enable support for row delete
enabledDelRow: true,
// Enable support for row Reoder
enableReOrderRow:true,
autoEdit: false,
enableCellNavigation: true
},
columnsEditor: [
{ column: 'date', editor: Slick.Editors.Date },
{ column: 'title', editor: Slick.Editors.Text }
]
}
})
},
{
id: 'graph',
label: 'Graph',
view: new recline.View.Graph({
model: dataset
})
},
{
id: 'map',
label: 'Map',
view: new recline.View.Map({
model: dataset
})
}
];
var multiView = new recline.View.MultiView({
model: dataset,
el: $el,
state: state,
views: views
});
return multiView;
} 

*/
