module.exports = function(grunt){

  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-contrib-compass');
  grunt.loadNpmTasks('grunt-contrib-jshint');
  grunt.loadNpmTasks('grunt-htmlhint');
  grunt.loadNpmTasks('grunt-autoprefixer');
  grunt.loadNpmTasks('grunt-cssc');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  //grunt.loadNpmTasks('grunt-express-server');

  grunt.initConfig({

    pkg: grunt.file.readJSON('package.json'),
  //  express: {
    //  options: {
        // Override defaults here
      //},
      //dev: {
        //options: {
          //script: 'path/to/dev/server.js'
        //}
      //}
    //}
    uglify: {
      dev: {
        options:{
          compress: true,
          preserveComments: false,
        }, //options
        files: {
              'dist/js/script.min.js' :       ['src/js/*.js'],
              'dist/js/jscalendar.min.js':    ['vendor/jscalendar-1.0/calendar.js',
                                               'vendor/jscalendar-1.0/lang/calendar-en.js',
                                               'vendor/jscalendar-1.0/calendar-setup.js'],
              'dist/js/zeroClipboard.min.js': ['vendor/zeroclipboard-2.2.0/dist/ZeroClipboard.js'],
              'dist/js/vendor.min.js' :       ['vendor/jquery/1.7.1/jquery.js',
                                               'vendor/underscore/1.4.4/underscore.js',
                                               'vendor/backbone/1.0.0/backbone.js',
                                               'vendor/mustache/0.5.0-dev/mustache.js',
                                               'vendor/bootstrap/2.0.2/bootstrap.js',
                                               'vendor/slickgrid/2.0.1/jquery.event.drag-2.2.js',
                                               'vendor/slickgrid/2.0.1/slick.core.js',
                                               'vendor/slickgrid/2.0.1/slick.grid.js',                                           
                                               'vendor/dist/recline.js',                                           
                                               'vendor/src/model.js',
                                               'vendor/src/backend.memory.js',        
                                               'vendor/src/view.grid.js',                                     
                                               'vendor/src/view.slickgrid.js',
                                               'vendor/src/view.map.js',
                                               'vendor/src/view.graph.js',
                                               'vendor/src/view.flot.js',
                                               'vendor/flotr2/flotr2.js',
                                               'vendor/src/widget.filtereditor.js',
                                               'vendor/src/widget.fields.js',
                                               'vendor/src/widget.pager.js', 
                                               'vendor/src/widget.queryeditor.js',
                                               'vendor/src/view.multiview.js',                                           
                                               'vendor/slickgrid/2.0.1/jquery-ui-1.8.16.custom.min.js',
                                               'vendor/slickgrid/2.0.1/jquery.event.drag-2.0.min.js',
                                               'vendor/slickgrid/2.0.1/slick.grid.min.js',
                                               'vendor/slickgrid/2.0.1/plugins/slick.rowselectionmodel.js',
                                               'vendor/slickgrid/2.0.1/plugins/slick.rowmovemanager.js',
                                               'vendor/moment/2.0.0/moment.js',                                           
                                               'vendor/flot/jquery.flot.js',
                                               'vendor/flot/jquery.flot.time.js']
        } //files
      } //dev
    }, //uglify
    jshint: {
      js_target: {
        src: ['src/js/*.js']
      }, //js_target
      options: { force: true }, //report JSHint errors but not fail the task
    }, //jshint
    
    cssc: {
      build: {
        options: {
          consolidateViaDeclarations: true,
          consolidateViaSelectors:    true,
          consolidateMediaQueries:    true
        }
      } //build
    }, //cssc 
    autoprefixer: {
      build: {
        expand: true,
        flatten: true,
        src: 'src/css/*.css', 
        dest: 'src/css'
      } //build
    }, //autoprefixe
    cssmin:{
      dev: {
        options:{
          compress: true,
          preserveComments: false,
        }, //options
        files:{
          'dist/css/style.min.css' : ['vendor/recline/css/bootstrap.css',
                                      'src/css/style.css',
                                      'vendor/leaflet/leaflet.css',
                                      'vendor/jscalendar-1.0/calendar-green.css',
                                      'vendor/recline/css/grid.css',
                                      'vendor/recline/css/slickgrid.css',
                                      'vendor/recline/css/multiview.css',
                                      'vendor/recline/vendor/bootstrap/2.0.2/css/bootstrap.css',
                                      'vendor/recline/css/flot.css'
                                      ]
        } //files 
      } //dev
    }, //cssmin
    htmlhint: {
      build: {
        options: {
          'tag-pair': true,
          'tagname-lowercase': true,
          'attr-lowercase': true,
          'attr-value-double-quotes': true,
          'spec-char-escape': true,
          'id-unique': true
        }, //options
        src: ['*.html']
      } //build
    }, //htmlhint
    watch: {
      options: { livereload: true }, // reloads browser on save
      scripts: {
                files: ['src/js/*.js'],
                tasks: ['jshint', 'uglify']
            }, //scripts
      html:{
        files: ['*.html'],
        tasks: ['htmlhint:build']
      }//,
     // css:{
       // files: ['**/*.css'],
        //tasks: ['autoprefixer:build','cssmin']
      //} //css
    } //watch
  }); //intiConfig



  // Register the default tasks.
  grunt.registerTask('default', 'watch'); 

};
