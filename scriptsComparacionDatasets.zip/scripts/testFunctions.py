#!/usr/bin/python
# -*- coding: utf-8 -*-

import xlwt

from nltk.corpus import wordnet as wn
from nltk.corpus import wordnet_ic
from nltk.corpus import genesis

comb1 = "LOGA-IGFF-COSN"
comb2 = "FREQ-IDFB-COSN"

minRatio = 0.25

brown_ic = wordnet_ic.ic('ic-brown.dat')
semcor_ic = wordnet_ic.ic('ic-semcor.dat')
genesis_ic = wn.ic(genesis, False, 0.0)

def JSONtestsToXLS(data):

	# Create xls file
	wb = xlwt.Workbook(encoding="utf-8")
	generalSheet = wb.add_sheet("Tests", cell_overwrite_ok=True)
	generalColumn = 0
	generalRow = 1

	words = data[0]["weights"].keys()

	for word in words:
		generalSheet.write(generalRow, generalColumn, word)
		generalRow += 1

	generalColumn = 1

	for modes in data:

		generalRow = 0
		modesText = modes["modes"]["localMode"] + "/" + modes["modes"]["globalMode"] + "/" + modes["modes"]["normalizationMode"]
		generalSheet.write(generalRow, generalColumn, modesText)

		generalRow = 1

		for word in modes["weights"].keys():
			generalSheet.write(generalRow, generalColumn, modes["weights"][word])
			generalRow += 1

		generalColumn += 1

	return wb


def calculateSimilarity(synset1, synset2):

	res_brown = synset1.res_similarity(synset2, brown_ic)
	res_genesis = synset1.res_similarity(synset2, genesis_ic)

	lin = synset1.lin_similarity(synset2, semcor_ic)

	jcn_brown = synset1.jcn_similarity(synset2, brown_ic)
	jcn_genesis = synset1.jcn_similarity(synset2, genesis_ic)

	lch = synset1.lch_similarity(synset2)

	wup = synset1.wup_similarity(synset2)

	path = synset1.path_similarity(synset2)

	return [res_brown, res_genesis, lin, jcn_brown, jcn_genesis, lch, wup, path]

def calculateLikenessValue(title1, weights1, title2, weights2):

	print("WEIGHTS")
	print(weights1)
	print(weights2)

	# Create xls file
	wb = xlwt.Workbook(encoding="utf-8")
	generalSheet = wb.add_sheet("Tests", cell_overwrite_ok=True)

	generalSheet.write(0, 0, "Palabra 1")
	generalSheet.write(0, 1, "Peso Comb1")
	generalSheet.write(0, 2, "Peso Comb2")
	generalSheet.write(0, 3, "Peso Mixto")
	generalSheet.write(0, 4, "Palabra 2")
	generalSheet.write(0, 5, "Peso Comb1")
	generalSheet.write(0, 6, "Peso Comb2")
	generalSheet.write(0, 7, "Peso Mixto")

	generalSheet.write(0, 8, "res_brown")
	generalSheet.write(0, 9, "res_genesis")
	generalSheet.write(0, 10, "lin")
	generalSheet.write(0, 11, "jcn_brown")
	generalSheet.write(0, 12, "jcn_genesis")
	generalSheet.write(0, 13, "lch")
	generalSheet.write(0, 14, "wup")
	generalSheet.write(0, 15, "path")

	generalRow = 1

	for word1 in weights1[comb1].keys():

		if ((weights1[comb1][word1] > minRatio) and (weights1[comb2][word1] > 0)) or ((weights1[comb1][word1] * weights1[comb2][word1]) > 0.1):

			print("1.", word1, weights1[comb1][word1], weights1[comb2][word1], weights1[comb1][word1] * weights1[comb2][word1])
			synset1 = wn.synsets(word1, pos=wn.NOUN)

			if len(synset1) > 0:

				for word2 in weights2[comb1].keys():

					if ((weights2[comb1][word2] > minRatio) and (weights2[comb2][word2] > 0)) or ((weights2[comb1][word2] * weights2[comb2][word2]) > 0.1):

						print("2.", word2, weights2[comb1][word2], weights2[comb2][word2], weights2[comb1][word2] * weights2[comb2][word2])
						synset2 = wn.synsets(word2, pos=wn.NOUN)

						if len(synset2) > 0:

							similarity = calculateSimilarity(synset1[0], synset2[0])

							generalSheet.write(generalRow, 0, word1)
							generalSheet.write(generalRow, 1, weights1[comb1][word1])
							generalSheet.write(generalRow, 2, weights1[comb2][word1])
							generalSheet.write(generalRow, 3, weights1[comb1][word1] * weights1[comb2][word1])
							generalSheet.write(generalRow, 4, word2)
							generalSheet.write(generalRow, 5, weights2[comb1][word2])
							generalSheet.write(generalRow, 6, weights2[comb2][word2])
							generalSheet.write(generalRow, 7, weights2[comb1][word2] * weights2[comb2][word2])

							generalSheet.write(generalRow, 8, similarity[0])
							generalSheet.write(generalRow, 9, similarity[1])
							generalSheet.write(generalRow, 10, similarity[2])
							generalSheet.write(generalRow, 11, similarity[3])
							generalSheet.write(generalRow, 12, similarity[4])
							generalSheet.write(generalRow, 13, similarity[5])
							generalSheet.write(generalRow, 14, similarity[6])
							generalSheet.write(generalRow, 15, similarity[7])

							generalRow += 1

	wb.save("tests/similarities/" + title1.replace(" ", "").replace("|", "") + "+" + title2.replace(" ", "").replace("|", "") + ".xls")