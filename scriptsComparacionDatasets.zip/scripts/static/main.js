
function showInfo() {
    document.getElementById("info").style.display = "block";
}