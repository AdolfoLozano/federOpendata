sudo apt install npm
sudo npm install pm2 -g
