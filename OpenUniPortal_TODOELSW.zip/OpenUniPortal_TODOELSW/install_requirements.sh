pip install -r requisitos.txt
python init_sqlite.py
python descarga_diccionarios.py
