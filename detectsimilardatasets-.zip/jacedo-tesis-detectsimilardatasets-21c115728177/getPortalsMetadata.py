#!/usr/bin/python
# -*- coding: utf-8 -*-

import sys
import requests
import json
from generateCoincidences import generateCoincidences, Dataset
import nltk

rdfFormats = ["rdf"]
socrataFormat = ["csv", "geojson", "json", "rdf", "xml"]

def getDatasetsInfoFromList(portal, datasets):
	data = []

	for dataset in datasets["result"]:
		print dataset
		response = requests.get(portal.replace("package_list", "package_show?id=" + str(dataset)))
		dataJson = json.loads(response.content)
		data.append(dataJson["result"])

	return data

def getNumCoincidences(title, coincidences):
	# function to test if something is a noun
	is_noun = lambda pos: pos[:2] == 'NN'
	# do the nlp stuff
	tokenized = nltk.word_tokenize(title)
	
	#poss = [(word, pos) for (word, pos) in nltk.pos_tag(tokenized)]
	#print poss 
	
	nouns = [word for (word, pos) in nltk.pos_tag(tokenized) if is_noun(pos)] 

	for noun in nouns:
		if noun not in coincidences.keys():
			coincidences[noun] = 0

		coincidences[noun] += 1



def getPortalInfo(portal, typePortal):

	discarded = {"noDCAT" : 0, "noRDF": 0}
	coincidences = {}

	print u"Iniciando proceso de obtención de datos", portal

	# Doing the request

	try:
		response = requests.get(portal)
		#response = requests.get("https://data.cityofchicago.org/api/views/metadata/v1")
		dataJson = json.loads(response.content)
		print "Datos descargados"
	except:
		print "Error, el portal \"" + portal + "\" no responde correctamente. ", sys.exc_info()[0]
		sys.exit(0)

	# Preparing the variables in order to iterate the response

	identifier = "id"
	keyword = "tags"

	if typePortal == "ckan" or typePortal == "dkan":
		title = "title"
		description = "notes"
		language = "language"
		theme = ""
		resources = "resources"

		dataJson = getDatasetsInfoFromList(portal, dataJson)

	elif typePortal == "socrata":
		title = "name"
		description = "description"
		language = ""
		theme = "category"
		resources = ""
	else:
		print "Error, no se reconoce el tipo de portal establecido - " + typePortal
		sys.exit(0)

	print "Variables: ", title, identifier, description, language, keyword, theme

	datasets = []

	# Get info from json object array

	print len(dataJson)
	index = 0

	for element in dataJson:
		print index
		dataset = Dataset()

		if title in element.keys():
			dataset.title = element[title]
			print element[title].encode("utf-8")

			#### Tokenizar titulo, guardar sustantivos y almacenar frecuencia de sustantivos en los títulos
			getNumCoincidences(dataset.title, coincidences)

		else:
			dataset.DCATformat = False

		if identifier in element.keys():
			dataset.identifier = element[identifier]

		if description in element.keys():
			dataset.description = element[description]
		else:
			dataset.DCATformat = False

		if keyword in element.keys() and element[keyword] != None:
			for key in element[keyword]:
				if type(key) is str:
					dataset.keyword.append(key)
				elif type(key) is dict:
					dataset.keyword.append(key["name"])


		if language != "" and language in element.keys():
			dataset.language = element[language]

		if theme != "" and theme in element.keys():
			dataset.theme = element[theme]
		
		if resources != "" and resources in element.keys():
			for resource in element[resources]:
				resourceFormat = resource["format"]
				if resourceFormat not in dataset.resourceFomarts:
					dataset.resourceFomarts.append(resourceFormat)

				if resourceFormat.lower() in rdfFormats:
					dataset.RDFResources.append(resource["url"])

		elif "dataUri" in element:
			urlData = element["dataUri"]
			for resourceFormat in socrataFormat:
				urlResource = urlData + "." + resourceFormat
				response = requests.get(urlResource)
				#print resourceFormat, response.status_code
				if response.status_code == 200:
					dataset.resourceFomarts.append(resourceFormat)

					if resourceFormat.lower() in rdfFormats:
						dataset.RDFResources.append(urlResource)

		print dataset.resourceFomarts, len(dataset.RDFResources)
		
		if len(dataset.RDFResources) > 0 and dataset.DCATformat == True:
			datasets.append(dataset)
		else:
			if len(dataset.RDFResources) == 0:
				discarded["noRDF"] += 1
			
			if dataset.DCATformat == False:
				discarded["noDCAT"] += 1

		index += 1
		if index == 100:
			break

	for key in coincidences:
		coincidences[key] = float(coincidences[key])/float(len(dataJson))

	return datasets, discarded, coincidences

if len(sys.argv) < 3:
	print 'Error, se necesitan dos portales de los que obtener datos. Opcionalmente se puede incluir el tipo del portal (ckan, socrata)'
	print 'El modo de empleo de este scritp es: $python ', sys.argv[0],' url_portal_1 url_portal_2 {ckan | socrata} {ckan | socrata}'
	sys.exit(0)


print u"Iniciando programa"

# Getting arguments from command line

portal1 = sys.argv[1]
portal2 = sys.argv[2]

if len(sys.argv) == 4:
	typePortal1 = sys.argv[3]
	typePortal2 = "ckan"
elif len(sys.argv) > 4:
	typePortal1 = sys.argv[3]
	typePortal2 = sys.argv[4]
else:
	typePortal1 = "ckan"
	typePortal2 = "ckan"

# Starting data obtaining

datasets1, discarded1, coincidences1 = getPortalInfo(portal1, typePortal1)

print "Coincidences 1", coincidences1
 
jsonObject = json.dumps(coincidences1)
f = open("coincidences1.json","w")
f.write(jsonObject)
f.close()

datasets2, discarded2, coincidences2 = getPortalInfo(portal2, typePortal2)

print "Coincidences 2", coincidences2
 
jsonObject = json.dumps(coincidences2)
f = open("coincidences2.json","w")
f.write(jsonObject)
f.close()

print "Discarded 1", discarded1
print "Discarded 2", discarded2

#### Volvar estadísticas en otro excel

generateCoincidences(datasets1, datasets2)