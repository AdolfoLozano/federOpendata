#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
from random import uniform
import xlwt #lib to write.

class Dataset:
	title = ""
	identifier = ""

	description = ""
	keyword = [] 
	language = "" 
	theme = "" 
	RDFResources = []
	DCATformat = True
	resourceFomarts = []

	def __init__(self):
		self.keyword = []
		self.resourceFomarts = []
		self.RDFResources = []

def getLikenessValue(dataset1, dataset2):
	return uniform(0.0, 1.0)

def generateCoincidences(datasets1, datasets2):

	print "Generando coincidencias"

	wb=xlwt.Workbook(encoding="utf-8")

	generalSheet=wb.add_sheet("General",cell_overwrite_ok=True)
	generalRow = 0

	for dataset1 in datasets1:

		generalColumn = 0

		generalSheet.write(generalRow,generalColumn,generalRow)
		generalColumn += 1
		generalSheet.write(generalRow,generalColumn,dataset1.title)

		for RDFResource in dataset1.RDFResources:
			generalColumn += 1
			generalSheet.write(generalRow,generalColumn,RDFResource)

		sheet=wb.add_sheet(str(generalRow),cell_overwrite_ok=True)

		row = 0

		for dataset2 in datasets2:

			# Obtener links rdf
			column = 0

			# Magic
			likenessValue = getLikenessValue(dataset1, dataset2)

			# Escribir en excel
			sheet.write(row,column,dataset2.title)
			column += 1
			sheet.write(row,column,likenessValue)

			for RDFResource in dataset2.RDFResources:
				column += 1
				sheet.write(row,column,RDFResource)

			row += 1

		generalRow += 1

	wb.save("results.xls")